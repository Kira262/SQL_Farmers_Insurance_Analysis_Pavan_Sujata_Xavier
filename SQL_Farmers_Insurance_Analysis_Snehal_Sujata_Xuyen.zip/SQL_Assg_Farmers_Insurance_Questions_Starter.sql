-- Group-Name : Snehal_Sujata_Xuyen
use ndap;

-- Check Nulls
SELECT
    SUM(
        CASE
            WHEN srcYear IS NULL THEN 1
            ELSE 0
        END
    ) AS check_null_srcYear,
    SUM(
        CASE
            WHEN srcStateName IS NULL THEN 1
            ELSE 0
        END
    ) AS check_null_srcStateName,
    SUM(
        CASE
            WHEN srcDistrictName IS NULL THEN 1
            ELSE 0
        END
    ) AS check_null_srcDistrictName,
    SUM(
        CASE
            WHEN InsuranceUnits IS NULL THEN 1
            ELSE 0
        END
    ) AS check_null_InsuranceUnits,
    SUM(
        CASE
            WHEN TotalFarmersCovered IS NULL THEN 1
            ELSE 0
        END
    ) AS check_null_TotalFarmersCovered,
    SUM(
        CASE
            WHEN InsuredLandArea IS NULL THEN 1
            ELSE 0
        END
    ) AS check_null_InsuredLandArea,
    SUM(
        CASE
            WHEN FarmersPremiumAmount IS NULL THEN 1
            ELSE 0
        END
    ) AS check_null_FarmersPremiumAmount,
    SUM(
        CASE
            WHEN SumInsured IS NULL THEN 1
            ELSE 0
        END
    ) AS check_null_SumInsured,
    SUM(
        CASE
            WHEN TotalPopulation IS NULL THEN 1
            ELSE 0
        END
    ) AS check_null_TotalPopulation
FROM
    farmersinsurancedata;

/*
- Variables to check for Null: srcYear, srcStateName, srcDistrictName, InsuranceUnits, TotalFarmersCovered, InsuredLandArea, FarmersPremiumAmount, SumInsured, TotalPopulation.
- All the counts of Null values are zero, so the output is unaffected by Null values.
 */
-- ----------------------------------------------------------------------------------------------
-- SECTION 1. 
-- SELECT Queries [5 Marks]
-- 	Q1.	Retrieve the names of all states (srcStateName) from the dataset.
-- ###
-- 	[2 Marks]
-- ###
-- TYPE YOUR CODE BELOW >
SELECT DISTINCT
    srcStateName
FROM
    FarmersInsuranceData
ORDER BY
    srcStateName;

/*
- The srcStateName variable has 25 states: 
'ANDHRA PRADESH', 'ASSAM', 'CHHATTISGARH', 'GOA', 'GUJARAT', 
'HARYANA', 'HIMACHAL PRADESH', 'JAMMU AND KASHMIR', 'JHARKHAND', 'KARNATAKA', 
'KERALA', 'MADHYA PRADESH', 'MAHARASHTRA', 'MANIPUR', 'ODISHA', 
'PUDUCHERRY', 'PUNJAB', 'RAJASTHAN', 'SIKKIM', 'TAMIL NADU',
'TELANGANA', 'TRIPURA', 'UTTAR PRADESH', 'UTTARAKHAND', 'WEST BENGAL'.
 */
-- ###
-- 	Q2.	Retrieve the total number of farmers covered (TotalFarmersCovered) and the sum insured (SumInsured) for each state (srcStateName), ordered by TotalFarmersCovered in descending order.
-- ###
-- 	[3 Marks]
-- ###
-- TYPE YOUR CODE BELOW >
SELECT
    srcStateName AS States,
    SUM(TotalFarmersCovered) AS total_farmers_covered,
    ROUND(SUM(SumInsured) * 100000, 2) AS total_sum_insured
FROM
    farmersinsurancedata
GROUP BY
    states
ORDER BY
    total_farmers_covered DESC;

/*
- Top coverage states: Madhya Pradesh, Maharashtra, Uttar Pradesh with over 9 million farmers, nearly 9 million farmers, and over 7 million farmers, respectively.
- Top sum insured in states: Madhya Pradesh also has the highest sum insured, about 841 billion INR, Rajasthan with over 6.8 million farmers and 536 billion INR of sum insured.
- Low coverage: States like Punjab (37 farmers), Goa (114 farmers), and Gujarat (405 farmers).
 */
-- ###
-- --------------------------------------------------------------------------------------
-- SECTION 2. 
-- Filtering Data (WHERE) [15 Marks]
-- 	Q3.	Retrieve all records where Year is '2020'.
-- ###
-- 	[2 Marks]
-- ###
-- TYPE YOUR CODE BELOW >
SELECT
    *
FROM
    farmersinsurancedata
WHERE
    srcYear = 2020;

-- ###
-- 	Q4.	Retrieve all rows where the TotalPopulationRural is greater than 1 million and the srcStateName is 'HIMACHAL PRADESH'.
-- ###
-- 	[3 Marks]
-- ###
-- TYPE YOUR CODE BELOW >
SELECT
    *
FROM
    farmersinsurancedata
WHERE
    TotalPopulationRural > 1000000
    AND srcStateName = 'HIMACHAL PRADESH';

/*
- Retrieved data has 4 rows in HIMACHAL PRADESH, and Kangra is the only one of three districts in HIMACHAL PRADESH state that meets the criterion.
 */
-- ###
-- 	Q5.	Retrieve the srcStateName, srcDistrictName, and the sum of FarmersPremiumAmount for each district in the year 2018, 
-- 		and display the results ordered by FarmersPremiumAmount in ascending order.
-- ###
-- 	[5 Marks]
-- ###
-- TYPE YOUR CODE BELOW >
SELECT
    srcStateName AS States,
    srcDistrictName AS Districts,
    ROUND(SUM(FarmersPremiumAmount) * 100000, 2) AS total_farmers_premium
FROM
    farmersinsurancedata
WHERE
    srcYear = 2018
GROUP BY
    States,
    Districts
ORDER BY
    total_farmers_premium ASC;

/*
- The lowest FarmersPremiumAmount is in several districts in Karnataka with 0 INR.
- The highest FarmersPremiumAmount is in Ujjain district in Madhya Pradesh state with 327,309,008.79 INR.
- Madhya Pradesh state has high premiums, where this state leads in farmer coverage as mentioned in question 2 (9,149,678 farmers).
 */
-- ###
-- 	Q6.	Retrieve the total number of farmers covered and the sum of the gross premium amount to be paid for each state where the insured land area is greater than 5.0 for the year 2018.
-- ###
-- 	[5 Marks]
-- ###
-- TYPE YOUR CODE BELOW >
SELECT
    srcStateName AS States,
    SUM(TotalFarmersCovered) AS total_farmers_coverd,
    ROUND(SUM(GrossPremiumAmountToBePaid) * 100000, 2) AS total_gross_premium
FROM
    farmersinsurancedata
WHERE
    InsuredLandArea > 5.0
    AND srcYear = 2018
GROUP BY
    States
ORDER BY
    total_farmers_coverd DESC;

/*
- The number of farmers covered ranges from 5,044 in Kerala to 2,614,548 in Uttar Pradesh.
- The gross premium ranges from approximately 27.07 million INR in Kerala to over 15.78 billion INR in Tamil Nadu.
 */
-- ###
-- ------------------------------------------------------------------------------------------------
-- SECTION 3.
-- Aggregation (GROUP BY) [10 marks]
-- 	Q7. 	Calculate the average insured land area (InsuredLandArea) for each year (srcYear).
-- ###
-- 	[3 Marks]
-- ###
-- TYPE YOUR CODE BELOW >
SELECT
    srcYear AS year,
    ROUND(AVG(InsuredLandArea) * 1000, 2) AS avg_insured_land
FROM
    farmersinsurancedata
GROUP BY
    srcYear
ORDER BY
    srcYear;

/*
- The average insured land area increased from 2018 to 2020, peaking in 2020, then slightly decreased in 2021.
- Lowest average insured land area was in 2018 at about 38,235.25 hectares, with the highest in 2020 at about 48,351.95 hectares.
 */
-- ###
-- 	Q8. 	Calculate the total number of farmers covered (TotalFarmersCovered) for each district (srcDistrictName) where Insurance units is greater than 0.
-- ###
-- 	[3 Marks]
-- ###
-- TYPE YOUR CODE BELOW >
SELECT
    srcDistrictName AS Districts,
    SUM(TotalFarmersCovered) AS total_farmer_covered
FROM
    farmersinsurancedata
WHERE
    InsuranceUnits > 0
GROUP BY
    Districts
ORDER BY
    total_farmer_covered DESC;

-- Count where Insurance units is greater than 0
SELECT
    COUNT(*) AS count_units_greater_zero,
    COUNT(DISTINCT srcDistrictName) AS count_district_greater_zero
FROM
    farmersinsurancedata
WHERE
    InsuranceUnits > 0;

/*
- From 2018 to 2021 the total farmers covered from 9 (Mahesana) to 544,741 (Parbhani)
 */
-- ###
-- 	Q9.	For each state (srcStateName), calculate the total premium amounts (FarmersPremiumAmount, StatePremiumAmount, GOVPremiumAmount) and the total number of farmers covered (TotalFarmersCovered). Only include records where the sum insured (SumInsured) is greater than 500,000 (remember to check for scaling).
-- ###
-- 	[4 Marks]
-- ###
-- TYPE YOUR CODE BELOW >
-- Check Nulls for request
SELECT
    COUNT(*) AS null_farmer_premium
FROM
    farmersinsurancedata
WHERE
    FarmersPremiumAmount IS NULL;

SELECT
    COUNT(*) AS null_state_premium
FROM
    farmersinsurancedata
WHERE
    StatePremiumAmount IS NULL;

SELECT
    COUNT(*) AS null_gov_premium
FROM
    farmersinsurancedata
WHERE
    GOVPremiumAmount IS NULL;

SELECT
    COUNT(*) AS null_farmers
FROM
    farmersinsurancedata
WHERE
    TotalFarmersCovered IS NULL;

-- For each state calculate the total premium amounts
SELECT
    srcStateName AS States,
    SUM(FarmersPremiumAmount) * 100000 AS total_farmers_premium,
    SUM(StatePremiumAmount) * 100000 AS total_states_premium,
    SUM(GOVPremiumAmount) * 100000 AS total_gov_premium,
    SUM(TotalFarmersCovered) AS total_farmer_covered
FROM
    farmersinsurancedata
WHERE
    SumInsured > 5
GROUP BY
    States
ORDER BY
    total_farmer_covered DESC;

/*
- There are non-nulls in FarmersPremiumAmount, StatePremiumAmount, GOVPremiumAmount, TotalFarmersCovered columns.
- Total number of farmer have covered range from 33 (PUNJAB) to 9,149,678 (MADHYA PRADESH)
- The lowest of total government premium is about 69.9 thousand INR (GUJARAT) and the highest is about 39.99 billion INR (MADHYA PRADESH)
- Sum of state premium range from 10.39 thousand INR (SIKKIM) to 42.75 billion INR (TAMIL NADU)
- Sum of farmer premium range from 113.35 thousand INR (GOA) to 13.99 billion INR (MADHYA PRADESH)
 */
-- ###
-- -------------------------------------------------------------------------------------------------
-- SECTION 4.
-- Sorting Data (ORDER BY) [10 Marks]
-- 	Q10.	Retrieve the top 5 districts (srcDistrictName) with the highest TotalPopulation in the year 2020.
-- ###
-- 	[2 Marks]
-- ###
-- TYPE YOUR CODE BELOW >
SELECT
    srcDistrictName AS Districts,
    TotalPopulation
FROM
    farmersinsurancedata
WHERE
    srcYear = 2020
ORDER BY
    TotalPopulation DESC
LIMIT
    5;

/*
- High population districts are Pune, Thane, Jaipur, Nashik, Allahabad
 */
-- ###
-- 	Q11.	Retrieve the srcStateName, srcDistrictName, and SumInsured for the 10 districts with the lowest non-zero FarmersPremiumAmount,  ordered by insured sum and then the FarmersPremiumAmount.
-- ###
-- 	[3 Marks]
-- ###
-- TYPE YOUR CODE BELOW >
WITH
    LowestPremiumDistricts AS (
        SELECT
            srcStateName,
            srcDistrictName,
            SumInsured,
            FarmersPremiumAmount
        FROM
            farmersinsurancedata
        WHERE
            FarmersPremiumAmount > 0
        ORDER BY
            FarmersPremiumAmount ASC
        LIMIT
            10
    )
SELECT
    srcStateName AS States,
    srcDistrictName AS Districts,
    SumInsured * 100000 AS sum_insured,
    FarmersPremiumAmount * 100000 AS farmer_premium
FROM
    LowestPremiumDistricts
ORDER BY
    sum_insured ASC,
    farmer_premium ASC;

/*
- Values  are lowest non-zero about 6 districts 10 INR and 4 districts 20 INR  farmer premium.
- Range of sum insured from 439.99 INR in Kakaburgi to 1590 INR in Hassan all in Karnataka state
 */
-- ###
-- 	Q12. 	Retrieve the top 3 states (srcStateName) along with the year (srcYear) where the ratio of insured farmers (TotalFarmersCovered) to the total population (TotalPopulation) is highest. 
-- 		Sort the results by the ratio in descending order.
-- ###
-- 	[5 Marks]
-- ###
-- TYPE YOUR CODE BELOW >
SELECT
    srcStateName AS States,
    srcYear,
    ROUND(
        SUM(TotalFarmersCovered) / SUM(TotalPopulation),
        4
    ) AS farmer_to_population_ratio,
    SUM(TotalFarmersCovered) AS total_farmers_covered,
    SUM(TotalPopulation) AS total_population
FROM
    farmersinsurancedata
WHERE
    TotalPopulation > 0
GROUP BY
    States,
    srcYear
ORDER BY
    farmer_to_population_ratio DESC
LIMIT
    3;

/*
- Top state of year is Chhattisgarh in 2021 have highest ratio 4.98% with 1,265,556 farmer covered out of a population if 25,405,378
- Tripura appeares twice 2020 and 2021 with ratios of 4.68% and 6.64% respectively. It is population remain constant 3,673,917 but farmer decreased from 172,048 to 170,345
- Tripura's population is much smaller than chhattisgarh.
 */
-- ###
-- -------------------------------------------------------------------------------------------------
-- SECTION 5.
-- String Functions [6 Marks]
-- 	Q13. 	Create StateShortName by retrieving the first 3 characters of the srcStateName for each unique state.
-- ###
-- 	[2 Marks]
-- ###
-- TYPE YOUR CODE BELOW >
SELECT DISTINCT
    srcStateName,
    LEFT (srcStateName, 3) AS StateShortName
FROM
    farmersinsurancedata
ORDER BY
    srcStateName;

/*
Use left string function to extract the first 3 characters of the full name states, sort the results alphabetically for readability.
 */
-- ###
-- 	Q14. 	Retrieve the srcDistrictName where the district name starts with 'B'.
-- ###
-- 	[2 Marks]
-- ###
-- TYPE YOUR CODE BELOW >
SELECT DISTINCT
    srcDistrictName
FROM
    farmersinsurancedata
WHERE
    srcDistrictName LIKE 'B%'
ORDER BY
    srcDistrictName;

/*
58 districts name where name starts with 'B'
The unique district names with characters after B, sort the results alphabetically for readablility.
 */
-- ###
-- 	Q15. 	Retrieve the srcStateName and srcDistrictName where the district name contains the word 'pur' at the end.
-- ###
-- 	[2 Marks]
-- ###
-- TYPE YOUR CODE BELOW >
SELECT DISTINCT
    srcStateName,
    srcDistrictName
FROM
    farmersinsurancedata
WHERE
    srcDistrictName LIKE '%pur'
ORDER BY
    srcStateName,
    srcDistrictName;

-- Count district end with 'pur'
SELECT
    count(distinct srcDistrictName)
FROM
    farmersinsurancedata
WHERE
    srcDistrictName LIKE '%pur';

-- ###
/*
54 names of district that end with 'pur'
The results sort by sate then district for readability. 
 */
-- -------------------------------------------------------------------------------------------------
-- SECTION 6.
-- Joins [14 Marks]
-- 	Q16. 	Perform an INNER JOIN between the srcStateName and srcDistrictName columns to retrieve the aggregated FarmersPremiumAmount for districts where the district’s Insurance units for an individual year are greater than 10.
-- ###
-- 	[4 Marks]
-- ###
-- TYPE YOUR CODE BELOW >
SELECT
    t1.srcStateName AS States,
    t1.srcDistrictName AS Districts,
    SUM(t1.FarmersPremiumAmount) * 100000 AS total_farmers_premium
FROM
    farmersinsurancedata AS t1
    INNER JOIN farmersinsurancedata AS t2 ON t1.srcStateName = t2.srcStateName
    AND t1.srcDistrictName = t2.srcDistrictName
WHERE
    t1.InsuranceUnits > 10
GROUP BY
    States,
    Districts
ORDER BY
    total_farmers_premium DESC;

/*
Self-join on the same table, use t1 and t2 are aliases joined on matching state and district names with InsuranceUnits is greater than 10.
488 unique sate-district pairs. 
Range of total farmers premium amount from 0 INR in many districts of Karnataka state to 5,81 billion INR in Bid district of Maharashtra state.
 */
-- ###
-- 	Q17.	Write a query that retrieves srcStateName, srcDistrictName, Year, TotalPopulation for each district and the the highest recorded FarmersPremiumAmount for that district over all available years
-- 		Return only those districts where the highest FarmersPremiumAmount exceeds 20 crores.
-- ###
-- 	[5 Marks]
-- ###
-- TYPE YOUR CODE BELOW >
WITH
    MaxPremium AS (
        SELECT
            srcStateName,
            srcDistrictName,
            MAX(FarmersPremiumAmount) AS max_farmers_premium_lakh
        FROM
            farmersinsurancedata
        GROUP BY
            srcStateName,
            srcDistrictName
        HAVING
            max_farmers_premium_lakh > 2000
    )
SELECT
    f.srcStateName,
    f.srcDistrictName,
    f.srcYear AS Year,
    f.TotalPopulation,
    m.max_farmers_premium_lakh * 100000 AS max_farmers_premium_inr
FROM
    farmersinsurancedata AS f
    INNER JOIN MaxPremium AS m ON f.srcStateName = m.srcStateName
    AND f.srcDistrictName = m.srcDistrictName
ORDER BY
    f.srcStateName,
    f.srcDistrictName,
    Year;

/*
- FarmersPremiumAmount is float in lakh INR (20 crore INR = 2,000 lakh INR) - (20,00,00,000/1,00,000 = 2,000)
- Calculates the maximum FarmersPremiumAmount for each state-dictrict pair.
- Filters for district where where the max premium exceeds 20 crores INR.
- Inner join the CTE with the original table to get all year for the filtered districts.
- Coverts the max premium to INR for clarity.
- Sorts by sate, district and year for readability.
 */
-- ###
-- 	Q18.	Perform a LEFT JOIN to combine the total population statistics with the farmers’ data (TotalFarmersCovered, SumInsured) for each district and state. 
-- 		Return the total premium amount (FarmersPremiumAmount) and the average population count for each district aggregated over the years, where the total FarmersPremiumAmount is greater than 100 crores.
-- 		Sort the results by total farmers' premium amount, highest first.
-- ###
-- 	[5 Marks]
-- ###
-- TYPE YOUR CODE BELOW >
SELECT
    t1.srcStateName,
    t1.srcDistrictName,
    SUM(t1.TotalFarmersCovered) AS total_farmers_covered,
    SUM(t1.SumInsured) * 100000 AS total_sum_insured,
    SUM(t1.FarmersPremiumAmount) * 100000 AS total_farmer_premium,
    AVG(t1.TotalPopulation) AS avg_population
FROM
    farmersinsurancedata AS t1
    LEFT JOIN farmersinsurancedata AS t2 ON t1.srcStateName = t2.srcStateName
    AND t1.srcDistrictName = t2.srcDistrictName
GROUP BY
    t1.srcStateName,
    t1.srcDistrictName
HAVING
    SUM(t1.FarmersPremiumAmount) > 10000
ORDER BY
    total_farmer_premium DESC;

-- Count number rows meeted the criterions
SELECT
    count(*)
from
    (
        SELECT
            t1.srcStateName,
            t1.srcDistrictName,
            SUM(t1.TotalFarmersCovered) AS total_farmers_covered,
            SUM(t1.SumInsured) * 100000 AS total_sum_insured,
            SUM(t1.FarmersPremiumAmount) * 100000 AS total_farmer_premium,
            AVG(t1.TotalPopulation) AS avg_population
        FROM
            farmersinsurancedata AS t1
            LEFT JOIN farmersinsurancedata AS t2 ON t1.srcStateName = t2.srcStateName
            AND t1.srcDistrictName = t2.srcDistrictName
        GROUP BY
            t1.srcStateName,
            t1.srcDistrictName
        HAVING
            SUM(t1.FarmersPremiumAmount) > 10000
    ) as t;

/*
- 100 cores INR = 100,00,00,000/1,00,000 = 10,000 lakh INR
- 1 lakh = 100,000 INR
- Use left join in same table to calculate with aggregated over the years where FarmersPremiumAmount more than 100 crores.
- 70 rows of total farmers covered range from 456,648 farmers in Jalgaon dictrict - Gujarat state to 5,722,128 farmers in Bid district - Maharashtra state.
- With 456,648 farmers in Jalgaon dictrict - Gujarat state is lowest total insured 24,300,431,762.70 INR and the total highest is in Ujjain district of Madhya Pradesh state 301,380,865,625 INR. 
- With 5,722,128 farmers in Bid district of Maharashtra state is the highest of total farmer premium exceeding 5,811,543,896.48 INR and the lowest is Guna district in MADHYA PRADESH state 1,047,931,994.63 INR.
 */
-- ###
-- -------------------------------------------------------------------------------------------------
-- SECTION 7.
-- Subqueries [10 Marks]
-- 	Q19.	Write a query to find the districts (srcDistrictName) where the TotalFarmersCovered is greater than the average TotalFarmersCovered across all records.
-- ###
-- 	[2 Marks]
-- ###
-- TYPE YOUR CODE BELOW >
SELECT
    srcDistrictName AS Districts,
    SUM(TotalFarmersCovered) AS total_farmer_covered
FROM
    farmersinsurancedata
GROUP BY
    srcDistrictName
HAVING
    SUM(TotalFarmersCovered) > (
        SELECT
            AVG(TotalFarmersCovered)
        FROM
            farmersinsurancedata
    )
ORDER BY
    srcDistrictName;

-- Count districts where the TotalFarmersCovered is greater than the average TotalFarmersCovered across all records
SELECT
    COUNT(Districts) AS count_districts
FROM
    (
        SELECT
            srcDistrictName AS Districts,
            SUM(TotalFarmersCovered) AS total_farmer_covered
        FROM
            farmersinsurancedata
        GROUP BY
            srcDistrictName
        HAVING
            SUM(TotalFarmersCovered) > (
                SELECT
                    AVG(TotalFarmersCovered)
                FROM
                    farmersinsurancedata
            )
        ORDER BY
            srcDistrictName
    ) AS t;

-- The average TotalFarmersCovered
SELECT
    AVG(TotalFarmersCovered) AS avg_total_farmers_covered
FROM
    farmersinsurancedata;

/*
- TotalFarmersCovered is greater than the average TotalFarmersCovered (27,621 farmers)
- Total farmers range from 27,673 in Karimganj district to 1,430,532
 */
-- ###
-- 	Q20.	Write a query to find the srcStateName where the SumInsured is higher than the SumInsured of the district with the highest FarmersPremiumAmount.
-- ###
-- 	[3 Marks]
-- ###
-- TYPE YOUR CODE BELOW >
SELECT
    srcStateName AS States,
    SUM(SumInsured) * 100000 AS sum_insured
FROM
    farmersinsurancedata
GROUP BY
    States
HAVING
    SUM(SumInsured) > (
        SELECT
            SUM(SumInsured)
        FROM
            farmersinsurancedata
        GROUP BY
            srcStateName,
            srcDistrictName
        ORDER BY
            SUM(FarmersPremiumAmount) DESC
        LIMIT
            1
    )
ORDER BY
    States;

/*
- 1 lakh = 100,000 INR
- 11 of 25 states where the SumInsured is higher than the SumInsured of the district with the highest FarmersPremiumAmount (64,228,772,656.25 INR)
- 11 states: andhra pradesh, assam, chhattisgarh, haryana, madhya pradesh, maharashtra,	odisha,	rajasthan, tamil nadu, uttar pradesh, west bengal
- The SumInsured of states have range from 80,678,672,303.4 INR in ASSAM to 841,319,828,865.05 INR in MADHYA PRADESH
 */
-- ###
-- 	Q21.	Write a query to find the srcDistrictName where the FarmersPremiumAmount is higher than the average FarmersPremiumAmount of the state that has the highest TotalPopulation.
-- ###
-- 	[5 Marks]
-- ###
-- TYPE YOUR CODE BELOW >
SELECT
    srcDistrictName
FROM
    farmersinsurancedata
GROUP BY
    srcDistrictName
HAVING
    SUM(FarmersPremiumAmount) > (
        SELECT
            AVG(FarmersPremiumAmount)
        FROM
            farmersinsurancedata
        WHERE
            srcStateName = (
                SELECT
                    srcStateName
                FROM
                    farmersinsurancedata
                GROUP BY
                    srcStateName
                ORDER BY
                    AVG(TotalPopulation) DESC
                LIMIT
                    1
            )
    )
ORDER BY
    srcDistrictName;

/*
- West Bengal state is the highest average population about 3,944,519 across over districts and years
- The FarmersPremiumAmount is higher than the average FarmersPremiumAmount 39,672,652.72 INR of the West Bengal state
- 235 of 541 districts met the criterions
 */
-- ###
-- -------------------------------------------------------------------------------------------------
-- SECTION 8.
-- Advanced SQL Functions (Window Functions) [10 Marks]
-- 	Q22.	Use the ROW_NUMBER() function to assign a row number to each record in the dataset ordered by total farmers covered in descending order.
-- ###
-- 	[3 Marks]
-- ###
-- TYPE YOUR CODE BELOW >
SELECT
    *,
    ROW_NUMBER() OVER (
        ORDER BY
            TotalFarmersCovered DESC
    ) AS row_farmers_covered
FROM
    farmersinsurancedata;

/*
- Function to assign t row number to each record that mean select all columns
- Total rank row number are 1820 rows start from Bid - Maharashtra to Patan - Gujarat
 */
-- ###
-- 	Q23.	Use the RANK() function to rank the districts (srcDistrictName) based on the SumInsured (descending) and partition by alphabetical srcStateName.
-- ###
-- 	[3 Marks]
-- ###
-- TYPE YOUR CODE BELOW >
SELECT
    srcStateName,
    srcDistrictName,
    SUM(SumInsured) * 100000 AS total_sum_insured,
    RANK() OVER (
        PARTITION BY
            srcStateName
        ORDER BY
            SUM(SumInsured) DESC
    ) AS district_rank
FROM
    farmersinsurancedata
GROUP BY
    srcStateName,
    srcDistrictName
ORDER BY
    srcStateName,
    district_rank;

/*
- 1 lakh = 100,000 INR
- Total rows: 541 for one row per district and state
- SumInsured has no Nulls
- total_sum_insured is in INR
- Separates the dataset into groups by state, rank districts within each state based on their total SumInsured, the highest getting rank 1.
- Same rank to ties and skips numbers after ties. 
 */
-- ###
-- 	Q24.	Use the SUM() window function to calculate a cumulative sum of FarmersPremiumAmount for each district (srcDistrictName), ordered ascending by the srcYear, partitioned by srcStateName.
-- ###
-- 	[4 Marks]
-- ###
-- TYPE YOUR CODE BELOW >
SELECT
    srcStateName,
    srcDistrictName,
    srcYear,
    FarmersPremiumAmount,
    SUM(FarmersPremiumAmount) OVER (
        PARTITION BY
            srcStateName,
            srcDistrictName
        ORDER BY
            srcYear
    ) AS cumulate_premium
FROM
    farmersinsurancedata
ORDER BY
    srcStateName,
    srcDistrictName,
    srcYear;

/*
- Total 1820 rows one row pwe district per year. 
- FarmersPremiumAmount in lakh INR (1 lakh = 100,000 INR). 
- Show the cumulative sum for each district separate the sum by state. 
- Order the cumulative sum within partition by year for each district. 
- Running total up to the current row
- FarmersPremiumAmount is non-null value.
 */
-- ###
-- -------------------------------------------------------------------------------------------------
-- SECTION 9.
-- Data Integrity (Constraints, Foreign Keys) [4 Marks]
-- 	Q25.	Create a table 'districts' with DistrictCode as the primary key and columns for DistrictName and StateCode. 
-- 		Create another table 'states' with StateCode as primary key and column for StateName.
-- ###
-- 	[2 Marks]
-- ###
-- TYPE YOUR CODE BELOW >
-- Create a states table
CREATE TABLE
    states (
        StateCode VARCHAR(10) PRIMARY KEY,
        StateName VARCHAR(255) NOT NULL
    );

-- Create a districts table
CREATE TABLE
    districts (
        DistrictCode VARCHAR(10) PRIMARY KEY,
        DistrictName VARCHAR(225) NOT NULL,
        StateCode VARCHAR(10) NOT NULL
    );

/*
- Create the states table then districts table because StateCode will reference it for a foreign key
- Define data types, primary key and constraints for both tables
 */
-- ###
-- 	Q26.	Add a foreign key constraint to the districts table that references the StateCode column from a states table.
-- ###
-- 	[2 Marks]
-- ###
-- TYPE YOUR CODE BELOW >
ALTER TABLE districts ADD CONSTRAINT statecode_districts FOREIGN KEY (StateCode) REFERENCES states (StateCode);

/*
- Add a foreign key constraint to StateCode column in the districts table. 
- The constraint references the StateCode column in the states table.
- Non-null in dataset
 */
-- ###
-- -------------------------------------------------------------------------------------------------
-- SECTION 10.
-- UPDATE and DELETE [6 Marks]
-- 	Q27.	Update the FarmersPremiumAmount to 500.0 for the record where rowID is 1.
-- ###
-- 	[2 Marks]
-- ###
-- TYPE YOUR CODE BELOW >
UPDATE farmersinsurancedata
SET
    FarmersPremiumAmount = 500.0
WHERE
    rowID = 1;

/*
- Update the FarmersPremiumAmount colum where rowID is 1
- Set FarmersPremiumAmount to 500.0 in lakh INR
 */
-- ###
SELECT
    *
FROM
    farmersinsurancedata
LIMIT
    5;

-- 	Q28.	Update the Year to '2021' for all records where srcStateName is 'HIMACHAL PRADESH'.
-- ###
-- 	[2 Marks]
-- ###
-- TYPE YOUR CODE BELOW >
UPDATE farmersinsurancedata
SET
    srcYear = 2021
WHERE
    srcStateName = 'HIMACHAL PRADESH';

/*
Set srcYear = 2021, all records for Himachai Pradesh will have set to 2021
 */
-- ###
-- 	Q29.	Delete all records where the TotalFarmersCovered is less than 10000 and Year is 2020.
-- ###
-- 	[2 Marks]
-- ###
-- TYPE YOUR CODE BELOW >
DELETE FROM farmersinsurancedata
WHERE
    TotalFarmersCovered < 10000
    AND srcYear = 2020;

/*
- Filters records with fewer than 10,000 farmers in year 2020
- Delete rows meet both conditions.
 */
-- ###